import React, { useState }  from "react"

export default function Calculator(){
  
    const[display,setDisplay] = useState('0');
    const[operator,setOperator] = useState('');
    const[currentValue,setCurrentValue] = useState('');
    const[isWaitingForSecondOperand,setIsWaitingForSecondOperand] = useState(false);

    function handleValue(digit){

      if(isWaitingForSecondOperand){
        setDisplay(display+digit);
        setIsWaitingForSecondOperand(false);
      }
      else{
        setDisplay((prevDisplay)=>prevDisplay==='0'?digit:prevDisplay+digit);
      }

    }

    function handleOperator(op){

      if(operator !== '' && !isWaitingForSecondOperand){
        setDisplay("Valid for 2 operands")
        return;
      }

        setCurrentValue(display);
        setOperator(op);
        setDisplay(display+op);
        setIsWaitingForSecondOperand(true);
      
    }

    function performCalculation(){

      if(!operator && isWaitingForSecondOperand)
      return;
      
      let [left,right] = display.split(operator)

      let num1 = parseFloat(left);
      let num2 = parseFloat(right);

      let result;

      switch (operator){

        case '+' :
                result = num1+num2;
                break;
        case '-' :
                result = num1-num2;
                break;
        case '*' :
                result = num1*num2;
                break;
        case '/' :
                result = num1/num2;
                break;
        
        default :
        result = 0
      }

    
    setDisplay(result);
    setOperator('');
    setCurrentValue(result);
    setIsWaitingForSecondOperand(false)

    }


    return <>
    <div className="calculator">
      <div className="display">{display}</div>
      <div className="keypad">
        <button className="key-operator" onClick={()=>handleOperator('/')} >/</button>
        <button onClick={(e)=>handleValue('7')}>7</button>
        <button onClick={(e)=>handleValue('8')} >8</button>
        <button onClick={(e)=>handleValue('9')} >9</button>
        <button className="key-operator"  onClick={()=>handleOperator('*')} >*</button>
        <button onClick={(e)=>handleValue('4')} >4</button>
        <button onClick={(e)=>handleValue('5')} >5</button>
        <button onClick={(e)=>handleValue('6')} >6</button>
        <button className="key-operator"  onClick={()=>handleOperator('-')} >-</button>
        <button onClick={(e)=>handleValue('1')} >1</button>
        <button onClick={(e)=>handleValue('2')} >2</button>
        <button onClick={(e)=>handleValue('3')} >3</button>
        <button className="key-operator"  onClick={()=>handleOperator('+')} >+</button>
        <button onClick={(e)=>handleValue('0')} >0</button>
        <button className="key-clear">C</button>
        <button className="key-equal" onClick={performCalculation} >=</button>
      </div>
    </div>
    </>
}